﻿ 
           KMS-Service command Line Parameters:
          ——————————————————————————————————————
  -Port <Port Value> - KMS Port. Range from 1 to 65535
         -PWin <PID> - Windows PID
         -PO14 <PID> - Office 2010 PID
         -PO15 <PID> - Office 2013 PID
      -AI <Interval> - Activation Interval. Range from 15 to 43200 minutes
      -RI <Interval> - Renewal Interval. Range from 15 to 43200 minutes
   KillProcessOnPort - Force to open the KMS Port if this is present.
                -Log - Log file Enabled.
		 -IP - Show IP address Clients Computers.
        -Hwid <HWID> - Machine Hardware Hash.

